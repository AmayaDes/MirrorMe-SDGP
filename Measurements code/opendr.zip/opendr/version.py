version = '0.73'
short_version = version
full_version = version
